This program is a implementation of " ROBUST MVDR BEAMFORMING USING TIME-FREQUENCY MASKS FOR ONLINE/OFFLINE ASR IN NOISE" for chime3/chime4 data

This is a Comoplex Gaussian Mixture Model (CGMM) based MVDR beamforming;

I just implement the batch process of the paper.

The old verison has been moved to branch old_toy_mvdr

I can't guarantee the performance. Maybe there are some bugs. If you found that , I wiil appreciate your suggestions. 

test.m gives a detailed instruction about how to run the code. 

This code depends on voicebox. Doownload and add the path to your matlab. 
http://www.ee.ic.ac.uk/hp/staff/dmb/voicebox/voicebox.html
